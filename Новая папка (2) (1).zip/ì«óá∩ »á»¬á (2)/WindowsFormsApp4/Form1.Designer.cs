﻿
namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nalicieReceptaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.таро1DataSet = new WindowsFormsApp4.таро1DataSet();
            this.onlaynZakazBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.onlayn_zakazTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Onlayn_zakazTableAdapter();
            this.zakupkaMedikamentovBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zakupka_medikamentovTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Zakupka_medikamentovTableAdapter();
            this.otdelBuhgalteriiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.otdel_buhgalteriiTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Otdel_buhgalteriiTableAdapter();
            this.Добавить = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.nalicie_receptaTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Nalicie_receptaTableAdapter();
            this.button3 = new System.Windows.Forms.Button();
            this.adresDostavkiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.adres_dostavkiTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Adres_dostavkiTableAdapter();
            this.sotrudnikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sotrudnikTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.SotrudnikTableAdapter();
            this.naimenovanieMedikamentovBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.naimenovanie_medikamentovTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Naimenovanie_medikamentovTableAdapter();
            this.iDOnlZakDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fIOZakazchikaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.obschayaStoimostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresDostavkiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomerTelefonaKlientaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Obeyom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Recept = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Med = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Sotrud = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Adres = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.SaveButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nalicieReceptaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.таро1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlaynZakazBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakupkaMedikamentovBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otdelBuhgalteriiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adresDostavkiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.naimenovanieMedikamentovBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDOnlZakDataGridViewTextBoxColumn,
            this.fIOZakazchikaDataGridViewTextBoxColumn,
            this.obschayaStoimostDataGridViewTextBoxColumn,
            this.adresDostavkiDataGridViewTextBoxColumn,
            this.nomerTelefonaKlientaDataGridViewTextBoxColumn,
            this.Obeyom,
            this.ID_Recept,
            this.ID_Med,
            this.ID_Sotrud,
            this.ID_Adres});
            this.dataGridView1.DataSource = this.onlaynZakazBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(19, 29);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(984, 359);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dataGridView1_UserDeletingRow);
            // 
            // nalicieReceptaBindingSource
            // 
            this.nalicieReceptaBindingSource.DataMember = "Nalicie recepta";
            this.nalicieReceptaBindingSource.DataSource = this.таро1DataSet;
            // 
            // таро1DataSet
            // 
            this.таро1DataSet.DataSetName = "таро1DataSet";
            this.таро1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // onlaynZakazBindingSource
            // 
            this.onlaynZakazBindingSource.DataMember = "Onlayn zakaz";
            this.onlaynZakazBindingSource.DataSource = this.таро1DataSet;
            // 
            // onlayn_zakazTableAdapter
            // 
            this.onlayn_zakazTableAdapter.ClearBeforeFill = true;
            // 
            // zakupkaMedikamentovBindingSource
            // 
            this.zakupkaMedikamentovBindingSource.DataMember = "Zakupka medikamentov";
            this.zakupkaMedikamentovBindingSource.DataSource = this.таро1DataSet;
            // 
            // zakupka_medikamentovTableAdapter
            // 
            this.zakupka_medikamentovTableAdapter.ClearBeforeFill = true;
            // 
            // otdelBuhgalteriiBindingSource
            // 
            this.otdelBuhgalteriiBindingSource.DataMember = "Otdel buhgalterii";
            this.otdelBuhgalteriiBindingSource.DataSource = this.таро1DataSet;
            // 
            // otdel_buhgalteriiTableAdapter
            // 
            this.otdel_buhgalteriiTableAdapter.ClearBeforeFill = true;
            // 
            // Добавить
            // 
            this.Добавить.BackColor = System.Drawing.SystemColors.Highlight;
            this.Добавить.Location = new System.Drawing.Point(19, 394);
            this.Добавить.Name = "Добавить";
            this.Добавить.Size = new System.Drawing.Size(118, 23);
            this.Добавить.TabIndex = 3;
            this.Добавить.Text = "Добавление данных";
            this.Добавить.UseVisualStyleBackColor = false;
            this.Добавить.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Highlight;
            this.button2.Location = new System.Drawing.Point(143, 394);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Найти";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkOrchid;
            this.button1.Location = new System.Drawing.Point(1094, 533);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Выход";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // nalicie_receptaTableAdapter
            // 
            this.nalicie_receptaTableAdapter.ClearBeforeFill = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Lime;
            this.button3.Location = new System.Drawing.Point(935, 533);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(154, 23);
            this.button3.TabIndex = 8;
            this.button3.Text = "Следующая таблица";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // adresDostavkiBindingSource
            // 
            this.adresDostavkiBindingSource.DataMember = "Adres dostavki";
            this.adresDostavkiBindingSource.DataSource = this.таро1DataSet;
            // 
            // adres_dostavkiTableAdapter
            // 
            this.adres_dostavkiTableAdapter.ClearBeforeFill = true;
            // 
            // sotrudnikBindingSource
            // 
            this.sotrudnikBindingSource.DataMember = "Sotrudnik";
            this.sotrudnikBindingSource.DataSource = this.таро1DataSet;
            // 
            // sotrudnikTableAdapter
            // 
            this.sotrudnikTableAdapter.ClearBeforeFill = true;
            // 
            // naimenovanieMedikamentovBindingSource
            // 
            this.naimenovanieMedikamentovBindingSource.DataMember = "Naimenovanie medikamentov";
            this.naimenovanieMedikamentovBindingSource.DataSource = this.таро1DataSet;
            // 
            // naimenovanie_medikamentovTableAdapter
            // 
            this.naimenovanie_medikamentovTableAdapter.ClearBeforeFill = true;
            // 
            // iDOnlZakDataGridViewTextBoxColumn
            // 
            this.iDOnlZakDataGridViewTextBoxColumn.DataPropertyName = "ID_OnlZak";
            this.iDOnlZakDataGridViewTextBoxColumn.HeaderText = "ID_OnlZak";
            this.iDOnlZakDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDOnlZakDataGridViewTextBoxColumn.Name = "iDOnlZakDataGridViewTextBoxColumn";
            this.iDOnlZakDataGridViewTextBoxColumn.Width = 125;
            // 
            // fIOZakazchikaDataGridViewTextBoxColumn
            // 
            this.fIOZakazchikaDataGridViewTextBoxColumn.DataPropertyName = "FIO Zakazchika";
            this.fIOZakazchikaDataGridViewTextBoxColumn.HeaderText = "FIO Zakazchika";
            this.fIOZakazchikaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.fIOZakazchikaDataGridViewTextBoxColumn.Name = "fIOZakazchikaDataGridViewTextBoxColumn";
            this.fIOZakazchikaDataGridViewTextBoxColumn.Width = 125;
            // 
            // obschayaStoimostDataGridViewTextBoxColumn
            // 
            this.obschayaStoimostDataGridViewTextBoxColumn.DataPropertyName = "Obschaya stoimost";
            this.obschayaStoimostDataGridViewTextBoxColumn.HeaderText = "Obschaya stoimost";
            this.obschayaStoimostDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.obschayaStoimostDataGridViewTextBoxColumn.Name = "obschayaStoimostDataGridViewTextBoxColumn";
            this.obschayaStoimostDataGridViewTextBoxColumn.Width = 125;
            // 
            // adresDostavkiDataGridViewTextBoxColumn
            // 
            this.adresDostavkiDataGridViewTextBoxColumn.DataPropertyName = "Adres dostavki";
            this.adresDostavkiDataGridViewTextBoxColumn.HeaderText = "Adres dostavki";
            this.adresDostavkiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.adresDostavkiDataGridViewTextBoxColumn.Name = "adresDostavkiDataGridViewTextBoxColumn";
            this.adresDostavkiDataGridViewTextBoxColumn.Width = 125;
            // 
            // nomerTelefonaKlientaDataGridViewTextBoxColumn
            // 
            this.nomerTelefonaKlientaDataGridViewTextBoxColumn.DataPropertyName = "Nomer telefona klienta";
            this.nomerTelefonaKlientaDataGridViewTextBoxColumn.HeaderText = "Nomer telefona klienta";
            this.nomerTelefonaKlientaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nomerTelefonaKlientaDataGridViewTextBoxColumn.Name = "nomerTelefonaKlientaDataGridViewTextBoxColumn";
            this.nomerTelefonaKlientaDataGridViewTextBoxColumn.Width = 125;
            // 
            // Obeyom
            // 
            this.Obeyom.DataPropertyName = "Obeyom";
            this.Obeyom.HeaderText = "Obeyom";
            this.Obeyom.MinimumWidth = 6;
            this.Obeyom.Name = "Obeyom";
            this.Obeyom.Width = 125;
            // 
            // ID_Recept
            // 
            this.ID_Recept.DataPropertyName = "ID_Recept";
            this.ID_Recept.DataSource = this.nalicieReceptaBindingSource;
            this.ID_Recept.DisplayMember = "Nalichie recepta";
            this.ID_Recept.HeaderText = "Наличие рецепта";
            this.ID_Recept.MinimumWidth = 6;
            this.ID_Recept.Name = "ID_Recept";
            this.ID_Recept.ValueMember = "ID_Recept";
            this.ID_Recept.Width = 125;
            // 
            // ID_Med
            // 
            this.ID_Med.DataPropertyName = "ID_Med";
            this.ID_Med.DataSource = this.naimenovanieMedikamentovBindingSource;
            this.ID_Med.DisplayMember = "Naimenovanie medikamentov";
            this.ID_Med.HeaderText = "ID_Med";
            this.ID_Med.Name = "ID_Med";
            this.ID_Med.ValueMember = "ID_Med";
            // 
            // ID_Sotrud
            // 
            this.ID_Sotrud.DataPropertyName = "ID_Sotrud";
            this.ID_Sotrud.DataSource = this.sotrudnikBindingSource;
            this.ID_Sotrud.DisplayMember = "Familia";
            this.ID_Sotrud.HeaderText = "ID_Sotrud";
            this.ID_Sotrud.Name = "ID_Sotrud";
            this.ID_Sotrud.ValueMember = "ID_Sotrud";
            // 
            // ID_Adres
            // 
            this.ID_Adres.DataPropertyName = "ID_Adres";
            this.ID_Adres.DataSource = this.adresDostavkiBindingSource;
            this.ID_Adres.DisplayMember = "Naim_Adres_dostavki";
            this.ID_Adres.HeaderText = "ID_Adres";
            this.ID_Adres.Name = "ID_Adres";
            this.ID_Adres.ValueMember = "ID_Adres";
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(267, 394);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(75, 23);
            this.SaveButton.TabIndex = 9;
            this.SaveButton.Text = "Сохранить";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Red;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1181, 568);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Добавить);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nalicieReceptaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.таро1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlaynZakazBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakupkaMedikamentovBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otdelBuhgalteriiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adresDostavkiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.naimenovanieMedikamentovBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView dataGridView1;
        public таро1DataSet таро1DataSet;
        public System.Windows.Forms.BindingSource onlaynZakazBindingSource;
        public таро1DataSetTableAdapters.Onlayn_zakazTableAdapter onlayn_zakazTableAdapter;
        private System.Windows.Forms.BindingSource zakupkaMedikamentovBindingSource;
        private таро1DataSetTableAdapters.Zakupka_medikamentovTableAdapter zakupka_medikamentovTableAdapter;
        private System.Windows.Forms.BindingSource otdelBuhgalteriiBindingSource;
        private таро1DataSetTableAdapters.Otdel_buhgalteriiTableAdapter otdel_buhgalteriiTableAdapter;
        private System.Windows.Forms.Button Добавить;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource nalicieReceptaBindingSource;
        private таро1DataSetTableAdapters.Nalicie_receptaTableAdapter nalicie_receptaTableAdapter;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.BindingSource adresDostavkiBindingSource;
        private таро1DataSetTableAdapters.Adres_dostavkiTableAdapter adres_dostavkiTableAdapter;
        private System.Windows.Forms.BindingSource sotrudnikBindingSource;
        private таро1DataSetTableAdapters.SotrudnikTableAdapter sotrudnikTableAdapter;
        private System.Windows.Forms.BindingSource naimenovanieMedikamentovBindingSource;
        private таро1DataSetTableAdapters.Naimenovanie_medikamentovTableAdapter naimenovanie_medikamentovTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDOnlZakDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fIOZakazchikaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn obschayaStoimostDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresDostavkiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomerTelefonaKlientaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Obeyom;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Recept;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Med;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Sotrud;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Adres;
        private System.Windows.Forms.Button SaveButton;
    }
}

