﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class AddForm2 : Form
    {
        public AddForm2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                Form2 main = this.Owner as Form2;
                if (main != null)
                {
                    DataRow nRow = main.таро1DataSet.Tables[11].NewRow();
                    int rc = main.dataGridView1.RowCount + 1;
                    nRow[0] = rc;
                    nRow[1] = tbCena.Text;
                    nRow["Kolichestvo tovara"] = tbkol.Text;
                    nRow[5] = tbsrok.Text;
                    main.таро1DataSet.Tables[11].Rows.Add(nRow);
                    main.zakupka_medikamentovTableAdapter.Update(main.таро1DataSet.Zakupka_medikamentov);
                    main.таро1DataSet.Tables[11].AcceptChanges();
                    main.dataGridView1.Refresh();
                    tbCena.Text = "";
                    tbkol.Text = "";
                    tbsrok.Text = "";
                }
            }
        }
    }
}
