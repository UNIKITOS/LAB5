﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class AddForm5 : Form
    {
        public AddForm5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                {
                    {
                        Form3 main = this.Owner as Form3;
                        if (main != null)
                        {
                            DataRow nRow = main.таро1DataSet.Tables[5].NewRow();
                            int rc = main.dataGridView1.RowCount + 1;
                            nRow[0] = rc;
                            nRow[1] = tborg.Text;
                            nRow[2] = tbadres.Text;
                            main.таро1DataSet.Tables[5].Rows.Add(nRow);
                            main.organizacia_zakupkiTableAdapter.Update(main.таро1DataSet.Organizacia_zakupki);
                            main.таро1DataSet.Tables[5].AcceptChanges();
                            main.dataGridView1.Refresh();
                            tborg.Text = "";
                            tbadres.Text = "";
                        }
                    }
                }
            }
        }
    }
}
