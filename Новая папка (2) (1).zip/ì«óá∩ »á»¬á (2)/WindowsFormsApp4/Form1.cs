﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Naimenovanie_medikamentov". При необходимости она может быть перемещена или удалена.
            this.naimenovanie_medikamentovTableAdapter.Fill(this.таро1DataSet.Naimenovanie_medikamentov);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Sotrudnik". При необходимости она может быть перемещена или удалена.
            this.sotrudnikTableAdapter.Fill(this.таро1DataSet.Sotrudnik);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Adres_dostavki". При необходимости она может быть перемещена или удалена.
            this.adres_dostavkiTableAdapter.Fill(this.таро1DataSet.Adres_dostavki);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Nalicie_recepta". При необходимости она может быть перемещена или удалена.
            this.nalicie_receptaTableAdapter.Fill(this.таро1DataSet.Nalicie_recepta);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Otdel_buhgalterii". При необходимости она может быть перемещена или удалена.
            this.otdel_buhgalteriiTableAdapter.Fill(this.таро1DataSet.Otdel_buhgalterii);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Zakupka_medikamentov". При необходимости она может быть перемещена или удалена.
            this.zakupka_medikamentovTableAdapter.Fill(this.таро1DataSet.Zakupka_medikamentov);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Onlayn_zakaz". При необходимости она может быть перемещена или удалена.
            this.onlayn_zakazTableAdapter.Fill(this.таро1DataSet.Onlayn_zakaz);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                AddForm af = new AddForm();
                af.Owner = this;
                af.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SearchForm sf = new SearchForm();
            sf.Owner = this;
            sf.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
          
        }

        private void dataGridView1_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
                DialogResult dr = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (dr == DialogResult.Cancel)
                {
                    e.Cancel = true;
                }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form2 af = new Form2();
            af.Owner = this;
                af.Show();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            onlayn_zakazTableAdapter.Update(таро1DataSet);
        }
    }
}
