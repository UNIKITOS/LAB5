﻿
namespace WindowsFormsApp4
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDMedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.naimenovanieMedikamentovDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cenaZaEdinicuTovaraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.naimenovanieMedikamentovBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.таро1DataSet = new WindowsFormsApp4.таро1DataSet();
            this.naimenovanie_medikamentovTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Naimenovanie_medikamentovTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.iDOrganizDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.organizaciyaZakupkiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.organizaciaZakupkiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.organizacia_zakupkiTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Organizacia_zakupkiTableAdapter();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.iDDolzDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dolznostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.okladDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dolznostBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dolznostTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.DolznostTableAdapter();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.otdelBuhgalteriiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.otdel_buhgalteriiTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Otdel_buhgalteriiTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.otdelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.otdelTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.OtdelTableAdapter();
            this.sotrudnikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sotrudnikTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.SotrudnikTableAdapter();
            this.dolznostBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.iDOtdBuxDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Dolz = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Sotrud = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Otdel = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.graphikRabotyuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaveButton = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.naimenovanieMedikamentovBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.таро1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organizaciaZakupkiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dolznostBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otdelBuhgalteriiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otdelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dolznostBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDMedDataGridViewTextBoxColumn,
            this.naimenovanieMedikamentovDataGridViewTextBoxColumn,
            this.cenaZaEdinicuTovaraDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.naimenovanieMedikamentovBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(9, 10);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(334, 182);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dataGridView1_UserDeletingRow);
            // 
            // iDMedDataGridViewTextBoxColumn
            // 
            this.iDMedDataGridViewTextBoxColumn.DataPropertyName = "ID_Med";
            this.iDMedDataGridViewTextBoxColumn.HeaderText = "ID_Med";
            this.iDMedDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDMedDataGridViewTextBoxColumn.Name = "iDMedDataGridViewTextBoxColumn";
            this.iDMedDataGridViewTextBoxColumn.Width = 125;
            // 
            // naimenovanieMedikamentovDataGridViewTextBoxColumn
            // 
            this.naimenovanieMedikamentovDataGridViewTextBoxColumn.DataPropertyName = "Naimenovanie medikamentov";
            this.naimenovanieMedikamentovDataGridViewTextBoxColumn.HeaderText = "Naimenovanie medikamentov";
            this.naimenovanieMedikamentovDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.naimenovanieMedikamentovDataGridViewTextBoxColumn.Name = "naimenovanieMedikamentovDataGridViewTextBoxColumn";
            this.naimenovanieMedikamentovDataGridViewTextBoxColumn.Width = 125;
            // 
            // cenaZaEdinicuTovaraDataGridViewTextBoxColumn
            // 
            this.cenaZaEdinicuTovaraDataGridViewTextBoxColumn.DataPropertyName = "Cena za edinicu tovara";
            this.cenaZaEdinicuTovaraDataGridViewTextBoxColumn.HeaderText = "Cena za edinicu tovara";
            this.cenaZaEdinicuTovaraDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cenaZaEdinicuTovaraDataGridViewTextBoxColumn.Name = "cenaZaEdinicuTovaraDataGridViewTextBoxColumn";
            this.cenaZaEdinicuTovaraDataGridViewTextBoxColumn.Width = 125;
            // 
            // naimenovanieMedikamentovBindingSource
            // 
            this.naimenovanieMedikamentovBindingSource.DataMember = "Naimenovanie medikamentov";
            this.naimenovanieMedikamentovBindingSource.DataSource = this.таро1DataSet;
            // 
            // таро1DataSet
            // 
            this.таро1DataSet.DataSetName = "таро1DataSet";
            this.таро1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // naimenovanie_medikamentovTableAdapter
            // 
            this.naimenovanie_medikamentovTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDOrganizDataGridViewTextBoxColumn,
            this.organizaciyaZakupkiDataGridViewTextBoxColumn,
            this.adresDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.organizaciaZakupkiBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(419, 10);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(454, 182);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dataGridView2_UserDeletingRow);
            // 
            // iDOrganizDataGridViewTextBoxColumn
            // 
            this.iDOrganizDataGridViewTextBoxColumn.DataPropertyName = "ID_Organiz";
            this.iDOrganizDataGridViewTextBoxColumn.HeaderText = "ID_Organiz";
            this.iDOrganizDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDOrganizDataGridViewTextBoxColumn.Name = "iDOrganizDataGridViewTextBoxColumn";
            this.iDOrganizDataGridViewTextBoxColumn.Width = 125;
            // 
            // organizaciyaZakupkiDataGridViewTextBoxColumn
            // 
            this.organizaciyaZakupkiDataGridViewTextBoxColumn.DataPropertyName = "Organizaciya zakupki";
            this.organizaciyaZakupkiDataGridViewTextBoxColumn.HeaderText = "Organizaciya zakupki";
            this.organizaciyaZakupkiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.organizaciyaZakupkiDataGridViewTextBoxColumn.Name = "organizaciyaZakupkiDataGridViewTextBoxColumn";
            this.organizaciyaZakupkiDataGridViewTextBoxColumn.Width = 125;
            // 
            // adresDataGridViewTextBoxColumn
            // 
            this.adresDataGridViewTextBoxColumn.DataPropertyName = "Adres";
            this.adresDataGridViewTextBoxColumn.HeaderText = "Adres";
            this.adresDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.adresDataGridViewTextBoxColumn.Name = "adresDataGridViewTextBoxColumn";
            this.adresDataGridViewTextBoxColumn.Width = 125;
            // 
            // organizaciaZakupkiBindingSource
            // 
            this.organizaciaZakupkiBindingSource.DataMember = "Organizacia zakupki";
            this.organizaciaZakupkiBindingSource.DataSource = this.таро1DataSet;
            // 
            // organizacia_zakupkiTableAdapter
            // 
            this.organizacia_zakupkiTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDolzDataGridViewTextBoxColumn,
            this.dolznostDataGridViewTextBoxColumn,
            this.okladDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.dolznostBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(560, 262);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(334, 122);
            this.dataGridView3.TabIndex = 2;
            this.dataGridView3.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dataGridView3_UserDeletingRow);
            // 
            // iDDolzDataGridViewTextBoxColumn
            // 
            this.iDDolzDataGridViewTextBoxColumn.DataPropertyName = "ID_Dolz";
            this.iDDolzDataGridViewTextBoxColumn.HeaderText = "ID_Dolz";
            this.iDDolzDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDolzDataGridViewTextBoxColumn.Name = "iDDolzDataGridViewTextBoxColumn";
            this.iDDolzDataGridViewTextBoxColumn.Width = 125;
            // 
            // dolznostDataGridViewTextBoxColumn
            // 
            this.dolznostDataGridViewTextBoxColumn.DataPropertyName = "Dolznost";
            this.dolznostDataGridViewTextBoxColumn.HeaderText = "Dolznost";
            this.dolznostDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dolznostDataGridViewTextBoxColumn.Name = "dolznostDataGridViewTextBoxColumn";
            this.dolznostDataGridViewTextBoxColumn.Width = 125;
            // 
            // okladDataGridViewTextBoxColumn
            // 
            this.okladDataGridViewTextBoxColumn.DataPropertyName = "Oklad";
            this.okladDataGridViewTextBoxColumn.HeaderText = "Oklad";
            this.okladDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.okladDataGridViewTextBoxColumn.Name = "okladDataGridViewTextBoxColumn";
            this.okladDataGridViewTextBoxColumn.Width = 125;
            // 
            // dolznostBindingSource
            // 
            this.dolznostBindingSource.DataMember = "Dolznost";
            this.dolznostBindingSource.DataSource = this.таро1DataSet;
            // 
            // dolznostTableAdapter
            // 
            this.dolznostTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDOtdBuxDataGridViewTextBoxColumn,
            this.ID_Dolz,
            this.ID_Sotrud,
            this.ID_Otdel,
            this.graphikRabotyuDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.otdelBuhgalteriiBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(9, 262);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.RowTemplate.Height = 24;
            this.dataGridView4.Size = new System.Drawing.Size(516, 122);
            this.dataGridView4.TabIndex = 3;
            this.dataGridView4.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dataGridView4_UserDeletingRow);
            // 
            // otdelBuhgalteriiBindingSource
            // 
            this.otdelBuhgalteriiBindingSource.DataMember = "Otdel buhgalterii";
            this.otdelBuhgalteriiBindingSource.DataSource = this.таро1DataSet;
            // 
            // otdel_buhgalteriiTableAdapter
            // 
            this.otdel_buhgalteriiTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Highlight;
            this.button1.Location = new System.Drawing.Point(9, 197);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 19);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить данные";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Highlight;
            this.button2.Location = new System.Drawing.Point(419, 197);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(106, 19);
            this.button2.TabIndex = 5;
            this.button2.Text = "Добавить данные";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Highlight;
            this.button3.Location = new System.Drawing.Point(9, 389);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 19);
            this.button3.TabIndex = 6;
            this.button3.Text = "Добавить данные";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Highlight;
            this.button4.Location = new System.Drawing.Point(560, 389);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(110, 19);
            this.button4.TabIndex = 7;
            this.button4.Text = "Добавить данные";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Lime;
            this.button5.Location = new System.Drawing.Point(897, 560);
            this.button5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(56, 19);
            this.button5.TabIndex = 8;
            this.button5.Text = "Выход";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // otdelBindingSource
            // 
            this.otdelBindingSource.DataMember = "Otdel";
            this.otdelBindingSource.DataSource = this.таро1DataSet;
            // 
            // otdelTableAdapter
            // 
            this.otdelTableAdapter.ClearBeforeFill = true;
            // 
            // sotrudnikBindingSource
            // 
            this.sotrudnikBindingSource.DataMember = "Sotrudnik";
            this.sotrudnikBindingSource.DataSource = this.таро1DataSet;
            // 
            // sotrudnikTableAdapter
            // 
            this.sotrudnikTableAdapter.ClearBeforeFill = true;
            // 
            // dolznostBindingSource1
            // 
            this.dolznostBindingSource1.DataMember = "Dolznost";
            this.dolznostBindingSource1.DataSource = this.таро1DataSet;
            // 
            // iDOtdBuxDataGridViewTextBoxColumn
            // 
            this.iDOtdBuxDataGridViewTextBoxColumn.DataPropertyName = "ID_OtdBux";
            this.iDOtdBuxDataGridViewTextBoxColumn.HeaderText = "ID_OtdBux";
            this.iDOtdBuxDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDOtdBuxDataGridViewTextBoxColumn.Name = "iDOtdBuxDataGridViewTextBoxColumn";
            this.iDOtdBuxDataGridViewTextBoxColumn.Width = 125;
            // 
            // ID_Dolz
            // 
            this.ID_Dolz.DataPropertyName = "ID_Dolz";
            this.ID_Dolz.DataSource = this.dolznostBindingSource1;
            this.ID_Dolz.DisplayMember = "Dolznost";
            this.ID_Dolz.HeaderText = "ID_Dolz";
            this.ID_Dolz.Name = "ID_Dolz";
            this.ID_Dolz.ValueMember = "ID_Dolz";
            // 
            // ID_Sotrud
            // 
            this.ID_Sotrud.DataPropertyName = "ID_Sotrud";
            this.ID_Sotrud.DataSource = this.sotrudnikBindingSource;
            this.ID_Sotrud.DisplayMember = "Familia";
            this.ID_Sotrud.HeaderText = "ID_Sotrud";
            this.ID_Sotrud.Name = "ID_Sotrud";
            this.ID_Sotrud.ValueMember = "ID_Sotrud";
            // 
            // ID_Otdel
            // 
            this.ID_Otdel.DataPropertyName = "ID_Otdel";
            this.ID_Otdel.DataSource = this.otdelBindingSource;
            this.ID_Otdel.DisplayMember = "Otdel";
            this.ID_Otdel.HeaderText = "ID_Otdel";
            this.ID_Otdel.Name = "ID_Otdel";
            this.ID_Otdel.ValueMember = "ID_Otdel";
            // 
            // graphikRabotyuDataGridViewTextBoxColumn
            // 
            this.graphikRabotyuDataGridViewTextBoxColumn.DataPropertyName = "Graphik rabotyu";
            this.graphikRabotyuDataGridViewTextBoxColumn.HeaderText = "Graphik rabotyu";
            this.graphikRabotyuDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.graphikRabotyuDataGridViewTextBoxColumn.Name = "graphikRabotyuDataGridViewTextBoxColumn";
            this.graphikRabotyuDataGridViewTextBoxColumn.Width = 125;
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(139, 197);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(75, 23);
            this.SaveButton.TabIndex = 11;
            this.SaveButton.Text = "Сохранить";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(543, 197);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 12;
            this.button6.Text = "Сохранить";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(139, 389);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 13;
            this.button7.Text = "Сохранить";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(677, 389);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 14;
            this.button8.Text = "Сохранить";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Red;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(964, 590);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.naimenovanieMedikamentovBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.таро1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organizaciaZakupkiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dolznostBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otdelBuhgalteriiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otdelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dolznostBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView dataGridView1;
        public таро1DataSet таро1DataSet;
        public System.Windows.Forms.BindingSource naimenovanieMedikamentovBindingSource;
        public таро1DataSetTableAdapters.Naimenovanie_medikamentovTableAdapter naimenovanie_medikamentovTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDMedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn naimenovanieMedikamentovDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cenaZaEdinicuTovaraDataGridViewTextBoxColumn;
        public System.Windows.Forms.DataGridView dataGridView2;
        public System.Windows.Forms.BindingSource organizaciaZakupkiBindingSource;
        public таро1DataSetTableAdapters.Organizacia_zakupkiTableAdapter organizacia_zakupkiTableAdapter;
        public System.Windows.Forms.DataGridViewTextBoxColumn iDOrganizDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn organizaciyaZakupkiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresDataGridViewTextBoxColumn;
        public System.Windows.Forms.DataGridView dataGridView3;
        public System.Windows.Forms.BindingSource dolznostBindingSource;
        public таро1DataSetTableAdapters.DolznostTableAdapter dolznostTableAdapter;
        public System.Windows.Forms.DataGridViewTextBoxColumn iDDolzDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dolznostDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn okladDataGridViewTextBoxColumn;
        public System.Windows.Forms.DataGridView dataGridView4;
        public System.Windows.Forms.BindingSource otdelBuhgalteriiBindingSource;
        public таро1DataSetTableAdapters.Otdel_buhgalteriiTableAdapter otdel_buhgalteriiTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.BindingSource otdelBindingSource;
        private таро1DataSetTableAdapters.OtdelTableAdapter otdelTableAdapter;
        private System.Windows.Forms.BindingSource sotrudnikBindingSource;
        private таро1DataSetTableAdapters.SotrudnikTableAdapter sotrudnikTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDOtdBuxDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Dolz;
        private System.Windows.Forms.BindingSource dolznostBindingSource1;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Sotrud;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Otdel;
        private System.Windows.Forms.DataGridViewTextBoxColumn graphikRabotyuDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
    }
}