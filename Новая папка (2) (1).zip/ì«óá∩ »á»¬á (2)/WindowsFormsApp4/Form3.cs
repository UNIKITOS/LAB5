﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Sotrudnik". При необходимости она может быть перемещена или удалена.
            this.sotrudnikTableAdapter.Fill(this.таро1DataSet.Sotrudnik);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Otdel". При необходимости она может быть перемещена или удалена.
            this.otdelTableAdapter.Fill(this.таро1DataSet.Otdel);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Otdel_buhgalterii". При необходимости она может быть перемещена или удалена.
            this.otdel_buhgalteriiTableAdapter.Fill(this.таро1DataSet.Otdel_buhgalterii);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Dolznost". При необходимости она может быть перемещена или удалена.
            this.dolznostTableAdapter.Fill(this.таро1DataSet.Dolznost);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Organizacia_zakupki". При необходимости она может быть перемещена или удалена.
            this.organizacia_zakupkiTableAdapter.Fill(this.таро1DataSet.Organizacia_zakupki);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "таро1DataSet.Naimenovanie_medikamentov". При необходимости она может быть перемещена или удалена.
            this.naimenovanie_medikamentovTableAdapter.Fill(this.таро1DataSet.Naimenovanie_medikamentov);

        }

        private void dataGridView1_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (dr == DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        private void dataGridView2_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (dr == DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        private void dataGridView4_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (dr == DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        private void dataGridView3_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (dr == DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddForm4 af = new AddForm4();
            af.Owner = this;
            af.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddForm5 af = new AddForm5();
            af.Owner = this;
            af.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddForm6 af = new AddForm6();
            af.Owner = this;
            af.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AddForm7 af = new AddForm7();
            af.Owner = this;
            af.Show();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            naimenovanie_medikamentovTableAdapter.Update(таро1DataSet);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            organizacia_zakupkiTableAdapter.Update(таро1DataSet);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            otdel_buhgalteriiTableAdapter.Update(таро1DataSet);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            dolznostTableAdapter.Update(таро1DataSet);
        }
    }
}
