﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class AddForm4 : Form
    {
        public AddForm4()
        {
            InitializeComponent();
        }

        private void AddForm4_Load(object sender, EventArgs e)
        {
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                {
                    Form3 main = this.Owner as Form3;
                    if (main != null)
                    {
                        DataRow nRow = main.таро1DataSet.Tables[2].NewRow();
                        int rc = main.dataGridView1.RowCount + 1;
                        nRow[0] = rc;
                        nRow[1] = tbnaim.Text;
                        nRow[2] = tbedinicu.Text;
                        main.таро1DataSet.Tables[2].Rows.Add(nRow);
                        main.naimenovanie_medikamentovTableAdapter.Update(main.таро1DataSet.Naimenovanie_medikamentov);
                        main.таро1DataSet.Tables[2].AcceptChanges();
                        main.dataGridView1.Refresh();
                        tbnaim.Text = "";
                        tbedinicu.Text = "";
                    }
                }
            }
        }
    }
}
