﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class AddForm : Form
    {
        public AddForm()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            {
                Form1 main = this.Owner as Form1;
                if (main != null)
                {
                    DataRow nRow = main.таро1DataSet.Tables[4].NewRow();
                    int rc = main.dataGridView1.RowCount + 1;
                    nRow[0] = rc;
                    nRow["FIO Zakazchika"] = tbFIO.Text;
                    nRow["Adres dostavki"] = tbAdresdostavki.Text;
                    nRow["Obschaya stoimost"] = tbStoim.Text;
                    nRow["Obeyom"] = tbObeyom.Text;
                    nRow["Nomer telefona klienta"] = tbNomertelefonaclienta.Text;
                    main.таро1DataSet.Tables[4].Rows.Add(nRow);
                    main.onlayn_zakazTableAdapter.Update(main.таро1DataSet.Onlayn_zakaz);
                    main.таро1DataSet.Tables[4].AcceptChanges();
                    main.dataGridView1.Refresh();
                    tbFIO.Text = "";
                    tbAdresdostavki.Text = "";
                    tbStoim.Text = "";
                    tbNomertelefonaclienta.Text = "";
                    tbObeyom.Text = "";
                }
            }
        }
    }
}
