﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class AddForm3 : Form
    {
        public AddForm3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                {
                    Form2 main = this.Owner as Form2;
                    if (main != null)
                    {
                        DataRow nRow = main.таро1DataSet.Tables[9].NewRow();
                        int rc = main.dataGridView1.RowCount + 1;
                        nRow[0] = rc;
                        nRow[1] = tbImia.Text;
                        nRow[2] = tbFamilia.Text;
                        nRow[3] = tbOtchwstvo.Text;
                        nRow[4] = tbnomer.Text;
                        nRow[5] = tbData.Text;
                        nRow[6] = tbPasport.Text;
                        main.таро1DataSet.Tables[9].Rows.Add(nRow);
                        main.sotrudnikTableAdapter.Update(main.таро1DataSet.Sotrudnik);
                        main.таро1DataSet.Tables[9].AcceptChanges();
                        main.dataGridView1.Refresh();
                        tbImia.Text = "";
                        tbFamilia.Text = "";
                        tbOtchwstvo.Text = "";
                        tbnomer.Text = "";
                        tbData.Text = "";
                        tbPasport.Text = "";
                    }
                }
            }
        }
    }
}
