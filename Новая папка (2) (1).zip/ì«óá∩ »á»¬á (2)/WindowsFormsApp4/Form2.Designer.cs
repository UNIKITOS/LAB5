﻿
namespace WindowsFormsApp4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.таро1DataSet = new WindowsFormsApp4.таро1DataSet();
            this.zakupkaMedikamentovBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zakupka_medikamentovTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Zakupka_medikamentovTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.zakupkaMedikamentovBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.button4 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.iDSotrudDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imiaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.familiaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.otchestvoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomerTelefonaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataRozdeniaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pasportnyeDannyeSotrudniksDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sotrudnikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sotrudnikTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.SotrudnikTableAdapter();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.vzaimozamenyaemostBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vzaimozamenyaemostTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.VzaimozamenyaemostTableAdapter();
            this.recepturaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.recepturaTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.RecepturaTableAdapter();
            this.adresDostavkiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.adres_dostavkiTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Adres_dostavkiTableAdapter();
            this.organizaciaZakupkiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.organizacia_zakupkiTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Organizacia_zakupkiTableAdapter();
            this.nalicieReceptaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nalicie_receptaTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Nalicie_receptaTableAdapter();
            this.sotrudnikBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.naimenovanieMedikamentovBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.naimenovanie_medikamentovTableAdapter = new WindowsFormsApp4.таро1DataSetTableAdapters.Naimenovanie_medikamentovTableAdapter();
            this.iDZakMedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.obzyaCenaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kolichestvoTovaraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.srokGodnostiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Med = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Sotrud = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Vzaim = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Recept = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Organiz = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Adres = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ID_Receptura = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.SaveButton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.таро1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakupkaMedikamentovBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakupkaMedikamentovBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vzaimozamenyaemostBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recepturaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adresDostavkiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organizaciaZakupkiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nalicieReceptaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.naimenovanieMedikamentovBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(1106, 555);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(56, 19);
            this.button1.TabIndex = 0;
            this.button1.Text = "Выход";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Lime;
            this.button2.Location = new System.Drawing.Point(944, 555);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(143, 19);
            this.button2.TabIndex = 1;
            this.button2.Text = "Следующая таблица";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // таро1DataSet
            // 
            this.таро1DataSet.DataSetName = "таро1DataSet";
            this.таро1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // zakupkaMedikamentovBindingSource
            // 
            this.zakupkaMedikamentovBindingSource.DataMember = "Zakupka medikamentov";
            this.zakupkaMedikamentovBindingSource.DataSource = this.таро1DataSet;
            // 
            // zakupka_medikamentovTableAdapter
            // 
            this.zakupka_medikamentovTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDZakMedDataGridViewTextBoxColumn,
            this.obzyaCenaDataGridViewTextBoxColumn,
            this.kolichestvoTovaraDataGridViewTextBoxColumn,
            this.srokGodnostiDataGridViewTextBoxColumn,
            this.ID_Med,
            this.ID_Sotrud,
            this.ID_Vzaim,
            this.ID_Recept,
            this.ID_Organiz,
            this.ID_Adres,
            this.ID_Receptura});
            this.dataGridView1.DataSource = this.zakupkaMedikamentovBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(9, 10);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1059, 206);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dataGridView1_UserDeletingRow);
            // 
            // zakupkaMedikamentovBindingSource1
            // 
            this.zakupkaMedikamentovBindingSource1.DataMember = "Zakupka medikamentov";
            this.zakupkaMedikamentovBindingSource1.DataSource = this.таро1DataSet;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Highlight;
            this.button4.Location = new System.Drawing.Point(100, 225);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(66, 19);
            this.button4.TabIndex = 4;
            this.button4.Text = "Добавить";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDSotrudDataGridViewTextBoxColumn1,
            this.imiaDataGridViewTextBoxColumn,
            this.familiaDataGridViewTextBoxColumn,
            this.otchestvoDataGridViewTextBoxColumn,
            this.nomerTelefonaDataGridViewTextBoxColumn,
            this.dataRozdeniaDataGridViewTextBoxColumn,
            this.pasportnyeDannyeSotrudniksDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.sotrudnikBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(9, 249);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(961, 224);
            this.dataGridView2.TabIndex = 5;
            this.dataGridView2.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dataGridView2_UserDeletingRow);
            // 
            // iDSotrudDataGridViewTextBoxColumn1
            // 
            this.iDSotrudDataGridViewTextBoxColumn1.DataPropertyName = "ID_Sotrud";
            this.iDSotrudDataGridViewTextBoxColumn1.HeaderText = "ID_Sotrud";
            this.iDSotrudDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.iDSotrudDataGridViewTextBoxColumn1.Name = "iDSotrudDataGridViewTextBoxColumn1";
            this.iDSotrudDataGridViewTextBoxColumn1.Width = 125;
            // 
            // imiaDataGridViewTextBoxColumn
            // 
            this.imiaDataGridViewTextBoxColumn.DataPropertyName = "Imia";
            this.imiaDataGridViewTextBoxColumn.HeaderText = "Imia";
            this.imiaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.imiaDataGridViewTextBoxColumn.Name = "imiaDataGridViewTextBoxColumn";
            this.imiaDataGridViewTextBoxColumn.Width = 125;
            // 
            // familiaDataGridViewTextBoxColumn
            // 
            this.familiaDataGridViewTextBoxColumn.DataPropertyName = "Familia";
            this.familiaDataGridViewTextBoxColumn.HeaderText = "Familia";
            this.familiaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.familiaDataGridViewTextBoxColumn.Name = "familiaDataGridViewTextBoxColumn";
            this.familiaDataGridViewTextBoxColumn.Width = 125;
            // 
            // otchestvoDataGridViewTextBoxColumn
            // 
            this.otchestvoDataGridViewTextBoxColumn.DataPropertyName = "Otchestvo";
            this.otchestvoDataGridViewTextBoxColumn.HeaderText = "Otchestvo";
            this.otchestvoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.otchestvoDataGridViewTextBoxColumn.Name = "otchestvoDataGridViewTextBoxColumn";
            this.otchestvoDataGridViewTextBoxColumn.Width = 125;
            // 
            // nomerTelefonaDataGridViewTextBoxColumn
            // 
            this.nomerTelefonaDataGridViewTextBoxColumn.DataPropertyName = "Nomer telefona";
            this.nomerTelefonaDataGridViewTextBoxColumn.HeaderText = "Nomer telefona";
            this.nomerTelefonaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nomerTelefonaDataGridViewTextBoxColumn.Name = "nomerTelefonaDataGridViewTextBoxColumn";
            this.nomerTelefonaDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataRozdeniaDataGridViewTextBoxColumn
            // 
            this.dataRozdeniaDataGridViewTextBoxColumn.DataPropertyName = "Data rozdenia";
            this.dataRozdeniaDataGridViewTextBoxColumn.HeaderText = "Data rozdenia";
            this.dataRozdeniaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dataRozdeniaDataGridViewTextBoxColumn.Name = "dataRozdeniaDataGridViewTextBoxColumn";
            this.dataRozdeniaDataGridViewTextBoxColumn.Width = 125;
            // 
            // pasportnyeDannyeSotrudniksDataGridViewTextBoxColumn
            // 
            this.pasportnyeDannyeSotrudniksDataGridViewTextBoxColumn.DataPropertyName = "Pasportnye dannye sotrudniks";
            this.pasportnyeDannyeSotrudniksDataGridViewTextBoxColumn.HeaderText = "Pasportnye dannye sotrudniks";
            this.pasportnyeDannyeSotrudniksDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.pasportnyeDannyeSotrudniksDataGridViewTextBoxColumn.Name = "pasportnyeDannyeSotrudniksDataGridViewTextBoxColumn";
            this.pasportnyeDannyeSotrudniksDataGridViewTextBoxColumn.Width = 125;
            // 
            // sotrudnikBindingSource
            // 
            this.sotrudnikBindingSource.DataMember = "Sotrudnik";
            this.sotrudnikBindingSource.DataSource = this.таро1DataSet;
            // 
            // sotrudnikTableAdapter
            // 
            this.sotrudnikTableAdapter.ClearBeforeFill = true;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Highlight;
            this.button5.Location = new System.Drawing.Point(91, 478);
            this.button5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(66, 19);
            this.button5.TabIndex = 6;
            this.button5.Text = "Добавить";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Highlight;
            this.button6.Location = new System.Drawing.Point(22, 225);
            this.button6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(56, 19);
            this.button6.TabIndex = 7;
            this.button6.Text = "Найти";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // vzaimozamenyaemostBindingSource
            // 
            this.vzaimozamenyaemostBindingSource.DataMember = "Vzaimozamenyaemost";
            this.vzaimozamenyaemostBindingSource.DataSource = this.таро1DataSet;
            // 
            // vzaimozamenyaemostTableAdapter
            // 
            this.vzaimozamenyaemostTableAdapter.ClearBeforeFill = true;
            // 
            // recepturaBindingSource
            // 
            this.recepturaBindingSource.DataMember = "Receptura";
            this.recepturaBindingSource.DataSource = this.таро1DataSet;
            // 
            // recepturaTableAdapter
            // 
            this.recepturaTableAdapter.ClearBeforeFill = true;
            // 
            // adresDostavkiBindingSource
            // 
            this.adresDostavkiBindingSource.DataMember = "Adres dostavki";
            this.adresDostavkiBindingSource.DataSource = this.таро1DataSet;
            // 
            // adres_dostavkiTableAdapter
            // 
            this.adres_dostavkiTableAdapter.ClearBeforeFill = true;
            // 
            // organizaciaZakupkiBindingSource
            // 
            this.organizaciaZakupkiBindingSource.DataMember = "Organizacia zakupki";
            this.organizaciaZakupkiBindingSource.DataSource = this.таро1DataSet;
            // 
            // organizacia_zakupkiTableAdapter
            // 
            this.organizacia_zakupkiTableAdapter.ClearBeforeFill = true;
            // 
            // nalicieReceptaBindingSource
            // 
            this.nalicieReceptaBindingSource.DataMember = "Nalicie recepta";
            this.nalicieReceptaBindingSource.DataSource = this.таро1DataSet;
            // 
            // nalicie_receptaTableAdapter
            // 
            this.nalicie_receptaTableAdapter.ClearBeforeFill = true;
            // 
            // sotrudnikBindingSource1
            // 
            this.sotrudnikBindingSource1.DataMember = "Sotrudnik";
            this.sotrudnikBindingSource1.DataSource = this.таро1DataSet;
            // 
            // naimenovanieMedikamentovBindingSource
            // 
            this.naimenovanieMedikamentovBindingSource.DataMember = "Naimenovanie medikamentov";
            this.naimenovanieMedikamentovBindingSource.DataSource = this.таро1DataSet;
            // 
            // naimenovanie_medikamentovTableAdapter
            // 
            this.naimenovanie_medikamentovTableAdapter.ClearBeforeFill = true;
            // 
            // iDZakMedDataGridViewTextBoxColumn
            // 
            this.iDZakMedDataGridViewTextBoxColumn.DataPropertyName = "ID_ZakMed";
            this.iDZakMedDataGridViewTextBoxColumn.HeaderText = "ID_ZakMed";
            this.iDZakMedDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDZakMedDataGridViewTextBoxColumn.Name = "iDZakMedDataGridViewTextBoxColumn";
            this.iDZakMedDataGridViewTextBoxColumn.Width = 125;
            // 
            // obzyaCenaDataGridViewTextBoxColumn
            // 
            this.obzyaCenaDataGridViewTextBoxColumn.DataPropertyName = "Obzya cena";
            this.obzyaCenaDataGridViewTextBoxColumn.HeaderText = "Obzya cena";
            this.obzyaCenaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.obzyaCenaDataGridViewTextBoxColumn.Name = "obzyaCenaDataGridViewTextBoxColumn";
            this.obzyaCenaDataGridViewTextBoxColumn.Width = 125;
            // 
            // kolichestvoTovaraDataGridViewTextBoxColumn
            // 
            this.kolichestvoTovaraDataGridViewTextBoxColumn.DataPropertyName = "Kolichestvo tovara";
            this.kolichestvoTovaraDataGridViewTextBoxColumn.HeaderText = "Kolichestvo tovara";
            this.kolichestvoTovaraDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kolichestvoTovaraDataGridViewTextBoxColumn.Name = "kolichestvoTovaraDataGridViewTextBoxColumn";
            this.kolichestvoTovaraDataGridViewTextBoxColumn.Width = 125;
            // 
            // srokGodnostiDataGridViewTextBoxColumn
            // 
            this.srokGodnostiDataGridViewTextBoxColumn.DataPropertyName = "Srok godnosti";
            this.srokGodnostiDataGridViewTextBoxColumn.HeaderText = "Srok godnosti";
            this.srokGodnostiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.srokGodnostiDataGridViewTextBoxColumn.Name = "srokGodnostiDataGridViewTextBoxColumn";
            this.srokGodnostiDataGridViewTextBoxColumn.Width = 125;
            // 
            // ID_Med
            // 
            this.ID_Med.DataPropertyName = "ID_Med";
            this.ID_Med.DataSource = this.naimenovanieMedikamentovBindingSource;
            this.ID_Med.DisplayMember = "Naimenovanie medikamentov";
            this.ID_Med.HeaderText = "ID_Med";
            this.ID_Med.Name = "ID_Med";
            this.ID_Med.ValueMember = "ID_Med";
            // 
            // ID_Sotrud
            // 
            this.ID_Sotrud.DataPropertyName = "ID_Sotrud";
            this.ID_Sotrud.DataSource = this.sotrudnikBindingSource1;
            this.ID_Sotrud.DisplayMember = "Familia";
            this.ID_Sotrud.HeaderText = "ID_Sotrud";
            this.ID_Sotrud.Name = "ID_Sotrud";
            this.ID_Sotrud.ValueMember = "ID_Sotrud";
            // 
            // ID_Vzaim
            // 
            this.ID_Vzaim.DataPropertyName = "ID_Vzaim";
            this.ID_Vzaim.DataSource = this.vzaimozamenyaemostBindingSource;
            this.ID_Vzaim.DisplayMember = "Vzaimozamenyaemost";
            this.ID_Vzaim.HeaderText = "ID_Vzaim";
            this.ID_Vzaim.Name = "ID_Vzaim";
            this.ID_Vzaim.ValueMember = "ID_Vzaim";
            // 
            // ID_Recept
            // 
            this.ID_Recept.DataPropertyName = "ID_Recept";
            this.ID_Recept.DataSource = this.nalicieReceptaBindingSource;
            this.ID_Recept.DisplayMember = "Nalichie recepta";
            this.ID_Recept.HeaderText = "ID_Recept";
            this.ID_Recept.Name = "ID_Recept";
            this.ID_Recept.ValueMember = "ID_Recept";
            // 
            // ID_Organiz
            // 
            this.ID_Organiz.DataPropertyName = "ID_Organiz";
            this.ID_Organiz.DataSource = this.organizaciaZakupkiBindingSource;
            this.ID_Organiz.DisplayMember = "Organizaciya zakupki";
            this.ID_Organiz.HeaderText = "ID_Organiz";
            this.ID_Organiz.Name = "ID_Organiz";
            this.ID_Organiz.ValueMember = "ID_Organiz";
            // 
            // ID_Adres
            // 
            this.ID_Adres.DataPropertyName = "ID_Adres";
            this.ID_Adres.DataSource = this.adresDostavkiBindingSource;
            this.ID_Adres.DisplayMember = "Naim_Adres_dostavki";
            this.ID_Adres.HeaderText = "ID_Adres";
            this.ID_Adres.Name = "ID_Adres";
            this.ID_Adres.ValueMember = "ID_Adres";
            // 
            // ID_Receptura
            // 
            this.ID_Receptura.DataPropertyName = "ID_Receptura";
            this.ID_Receptura.DataSource = this.recepturaBindingSource;
            this.ID_Receptura.DisplayMember = "Receptura";
            this.ID_Receptura.HeaderText = "ID_Receptura";
            this.ID_Receptura.Name = "ID_Receptura";
            this.ID_Receptura.ValueMember = "ID_Receptura";
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(171, 221);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(75, 23);
            this.SaveButton.TabIndex = 10;
            this.SaveButton.Text = "Сохранить";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(171, 478);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 11;
            this.button3.Text = "Сохранить";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Red;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1173, 585);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.таро1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakupkaMedikamentovBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakupkaMedikamentovBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vzaimozamenyaemostBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recepturaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adresDostavkiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organizaciaZakupkiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nalicieReceptaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.naimenovanieMedikamentovBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        public таро1DataSet таро1DataSet;
        public System.Windows.Forms.BindingSource zakupkaMedikamentovBindingSource;
        public таро1DataSetTableAdapters.Zakupka_medikamentovTableAdapter zakupka_medikamentovTableAdapter;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource zakupkaMedikamentovBindingSource1;
        private System.Windows.Forms.Button button4;
        public System.Windows.Forms.DataGridView dataGridView2;
        public System.Windows.Forms.BindingSource sotrudnikBindingSource;
        public таро1DataSetTableAdapters.SotrudnikTableAdapter sotrudnikTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDSotrudDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn imiaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn familiaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn otchestvoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomerTelefonaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataRozdeniaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pasportnyeDannyeSotrudniksDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.BindingSource vzaimozamenyaemostBindingSource;
        private таро1DataSetTableAdapters.VzaimozamenyaemostTableAdapter vzaimozamenyaemostTableAdapter;
        private System.Windows.Forms.BindingSource recepturaBindingSource;
        private таро1DataSetTableAdapters.RecepturaTableAdapter recepturaTableAdapter;
        private System.Windows.Forms.BindingSource adresDostavkiBindingSource;
        private таро1DataSetTableAdapters.Adres_dostavkiTableAdapter adres_dostavkiTableAdapter;
        private System.Windows.Forms.BindingSource organizaciaZakupkiBindingSource;
        private таро1DataSetTableAdapters.Organizacia_zakupkiTableAdapter organizacia_zakupkiTableAdapter;
        private System.Windows.Forms.BindingSource nalicieReceptaBindingSource;
        private таро1DataSetTableAdapters.Nalicie_receptaTableAdapter nalicie_receptaTableAdapter;
        private System.Windows.Forms.BindingSource sotrudnikBindingSource1;
        private System.Windows.Forms.BindingSource naimenovanieMedikamentovBindingSource;
        private таро1DataSetTableAdapters.Naimenovanie_medikamentovTableAdapter naimenovanie_medikamentovTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDZakMedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn obzyaCenaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kolichestvoTovaraDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn srokGodnostiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Med;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Sotrud;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Vzaim;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Recept;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Organiz;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Adres;
        private System.Windows.Forms.DataGridViewComboBoxColumn ID_Receptura;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button button3;
    }
}